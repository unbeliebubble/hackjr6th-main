$(document).ready(function(){

    $(".sbtc0").show(0);
    $(".sbtc1").hide(0);
    $(".sbtc2").hide(0);
    $(".sbtc3").hide(0);
    $(".sbtc4").hide(0);
    $(".sbtc5").hide(0);

    $(".msbt0").click(function(){
        $(".sbtc0").show(0);
        $(".sbtc1").hide(0);
        $(".sbtc2").hide(0);
        $(".sbtc3").hide(0);
        $(".sbtc4").hide(0);
        $(".sbtc5").hide(0);
        $(".tile_pic_1").css("background-image", "url(https://github.com/anny881104/black6th/blob/master/A1.png?raw=true)" );
        $(".tile_pic_2").css("background-image", "url(https://github.com/anny881104/black6th/blob/master/B2.png?raw=true)" );
        $(".tile_pic_3").css("background-image", "url(https://github.com/anny881104/black6th/blob/master/K3.png?raw=true)" );
        $(".tile_pic_4").css("background-image", "url(https://github.com/anny881104/black6th/blob/master/L4.png?raw=true)" );
        $(".tile_pic_5").css("background-image", "url(https://github.com/anny881104/black6th/blob/master/L5.png?raw=true)" );
        $(".tile_pic_6").css("background-image", "url(https://github.com/anny881104/black6th/blob/master/B6.png?raw=true)" );
    });
    $(".msbt1").click(function(){
        $(".sbtc0").hide(0);
        $(".sbtc1").show(1);
        $(".sbtc2").hide(0);
        $(".sbtc3").hide(0);
        $(".sbtc4").hide(0);
        $(".sbtc5").hide(0);
        $(".tile_pic_1").css("background-image", "url(https://github.com/anny881104/black6th/blob/master/K1.png?raw=true)" );
        $(".tile_pic_2").css("background-image", "url(https://github.com/anny881104/black6th/blob/master/K2.png?raw=true)" );
        $(".tile_pic_3").css("background-image", "url(https://github.com/anny881104/black6th/blob/master/K3.png?raw=true)" );
        $(".tile_pic_4").css("background-image", "url(https://github.com/anny881104/black6th/blob/master/K4.png?raw=true)" );
        $(".tile_pic_5").css("background-image", "url(https://github.com/anny881104/black6th/blob/master/K5.png?raw=true)" );
        $(".tile_pic_6").css("background-image", "url(https://github.com/anny881104/black6th/blob/master/K6.png?raw=true)" );

        
    });
    $(".msbt2").click(function(){
        $(".sbtc0").hide(0);
        $(".sbtc2").show(1);
        $(".sbtc1").hide(0);
        $(".sbtc3").hide(0);
        $(".sbtc4").hide(0);
        $(".sbtc5").hide(0);
        $(".tile_pic_1").css("background-image", "url(https://github.com/anny881104/black6th/blob/master/B1.png?raw=true)" );
        $(".tile_pic_2").css("background-image", "url(https://github.com/anny881104/black6th/blob/master/B2.png?raw=true)" );
        $(".tile_pic_3").css("background-image", "url(https://github.com/anny881104/black6th/blob/master/B3.png?raw=true)" );
        $(".tile_pic_4").css("background-image", "url(https://github.com/anny881104/black6th/blob/master/B4.png?raw=true)" );
        $(".tile_pic_5").css("background-image", "url(https://github.com/anny881104/black6th/blob/master/B5.png?raw=true)" );
        $(".tile_pic_6").css("background-image", "url(https://github.com/anny881104/black6th/blob/master/B6.png?raw=true)" );

        
    });
    $(".msbt3").click(function(){
        $(".sbtc0").hide(0);
        $(".sbtc3").show(1);
        $(".sbtc2").hide(0);
        $(".sbtc1").hide(0);
        $(".sbtc4").hide(0);
        $(".sbtc5").hide(0);
        $(".tile_pic_1").css("background-image", "url(https://github.com/anny881104/black6th/blob/master/P1.png?raw=true)" );
        $(".tile_pic_2").css("background-image", "url(https://github.com/anny881104/black6th/blob/master/P2.png?raw=true)" );
        $(".tile_pic_3").css("background-image", "url(https://github.com/anny881104/black6th/blob/master/P3.png?raw=true)" );
        $(".tile_pic_4").css("background-image", "url(https://github.com/anny881104/black6th/blob/master/P4.png?raw=true)" );
        $(".tile_pic_5").css("background-image", "url(https://github.com/anny881104/black6th/blob/master/P5.png?raw=true)" );
        $(".tile_pic_6").css("background-image", "url(https://github.com/anny881104/black6th/blob/master/P6.png?raw=true)" );

        
    });
    $(".msbt4").click(function(){
        $(".sbtc0").hide(0);
        $(".sbtc4").show(1);
        $(".sbtc2").hide(0);
        $(".sbtc3").hide(0);
        $(".sbtc1").hide(0);
        $(".sbtc5").hide(0);
        $(".tile_pic_1").css("background-image", "url(https://github.com/anny881104/black6th/blob/master/A1.png?raw=true)" );
        $(".tile_pic_2").css("background-image", "url(https://github.com/anny881104/black6th/blob/master/A2.png?raw=true)" );
        $(".tile_pic_3").css("background-image", "url(https://github.com/anny881104/black6th/blob/master/A3.png?raw=true)" );
        $(".tile_pic_4").css("background-image", "url(https://github.com/anny881104/black6th/blob/master/A4.png?raw=true)" );
        $(".tile_pic_5").css("background-image", "url(https://github.com/anny881104/black6th/blob/master/A5.png?raw=true)" );
        $(".tile_pic_6").css("background-image", "url(https://github.com/anny881104/black6th/blob/master/A6.png?raw=true)" );

        
    });
    $(".msbt5").click(function(){
        $(".sbtc0").hide(0);
        $(".sbtc5").show(1);
        $(".sbtc2").hide(0);
        $(".sbtc3").hide(0);
        $(".sbtc4").hide(0);
        $(".sbtc1").hide(0);
        $(".tile_pic_1").css("background-image", "url(https://github.com/anny881104/black6th/blob/master/L1.png?raw=true)" );
        $(".tile_pic_2").css("background-image", "url(https://github.com/anny881104/black6th/blob/master/L2.png?raw=true)" );
        $(".tile_pic_3").css("background-image", "url(https://github.com/anny881104/black6th/blob/master/L3.png?raw=true)" );
        $(".tile_pic_4").css("background-image", "url(https://github.com/anny881104/black6th/blob/master/L4.png?raw=true)" );
        $(".tile_pic_5").css("background-image", "url(https://github.com/anny881104/black6th/blob/master/L5.png?raw=true)" );
        $(".tile_pic_6").css("background-image", "url(https://github.com/anny881104/black6th/blob/master/L6.png?raw=true)" );

        
    });
     


    
    

    
});